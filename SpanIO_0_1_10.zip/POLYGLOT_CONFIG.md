# SpanIO

## Installation
The configuration (configuration tab under details) takes a list of IP addresses (space separated) - Only use 1 per panel (ideally ethernet if available).  It is important that the IP address does not change.  There is also a flag to enable reading of a backup battery (percentage) if supported 

Start node after updating the configuration

To register the panel(s), one must start the node and then go to the panel, open the door and press the door contact (upper corner) 3 times (quickly) - the panel should then blink the light and it will go into register mode. Do this for all panels if more than 1 panel is installed 

